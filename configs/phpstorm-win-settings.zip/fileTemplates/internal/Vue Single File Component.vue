<template>
#[[$END$]]#
</template>

<script>
export default {
  name: "${COMPONENT_NAME}",
  data(){
    return {}
  },
  computed: {},
  methods: {},

}
</script>