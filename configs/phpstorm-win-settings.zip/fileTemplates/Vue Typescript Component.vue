<template>
#[[$END$]]#
</template>

<script lang="ts">
import {Component, Vue} from 'vue-property-decorator'

@Component({})
export default class ${NAME} extends Vue {

}
</script>
